# anfaenger-praktikum
Protokolle des Anfängerpraktikums der Physik an der TU-Dortmund.
Basierend auf dem Toolboxworkshop von Pep et Al.
